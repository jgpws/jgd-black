License Information

The JGD-Black Gtk2+ theme is released under the General Public License, version 3. More information can be found at http://www.gnu.org/copyleft/gpl.html.

This theme is provided as-is, although modifications may be provided in a new version for bug fixes and other changes.